package com.example.iqsignal;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.net.*;
import java.io.*;
import java.util.concurrent.*;
import java.util.*;

public class FloatingService extends Service {
    WindowManager wm; View panel; TextView signal, detail, pair; Handler handler=new Handler(Looper.getMainLooper());
    ExecutorService net=Executors.newSingleThreadExecutor();
    String symbol="BTCUSDT"; boolean busy=false; int idx=0;
    String[] symbols={"BTCUSDT","ETHUSDT","BNBUSDT","SOLUSDT"};
    int dp(float x){return (int)(getResources().getDisplayMetrics().density*x);}
    @Override public void onCreate(){super.onCreate(); startAsForeground(); showPanel(); update(); handler.postDelayed(tick,15000);}
    void startAsForeground(){
        String channelId="iq_signal_running";
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){
            NotificationChannel channel=new NotificationChannel(channelId,"Floating signal",NotificationManager.IMPORTANCE_LOW);
            NotificationManager manager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            if(manager!=null) manager.createNotificationChannel(channel);
        }
        Notification.Builder builder=Build.VERSION.SDK_INT>=Build.VERSION_CODES.O ? new Notification.Builder(this,channelId) : new Notification.Builder(this);
        builder.setContentTitle("IQ Floating Signal").setContentText("সিগন্যাল প্যানেল চালু আছে").setSmallIcon(android.R.drawable.ic_menu_info_details).setOngoing(true);
        startForeground(1001,builder.build());
    }
    Runnable tick=()->{update(); handler.postDelayed(tick,15000);};
    void showPanel(){
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout box=new LinearLayout(this); box.setOrientation(1); box.setPadding(dp(12),dp(9),dp(12),dp(9)); box.setBackgroundColor(Color.rgb(20,29,39));
        TextView head=new TextView(this); head.setText("IQ SIGNAL  ⋮"); head.setTextColor(Color.WHITE); head.setTextSize(14); head.setTypeface(null,1); box.addView(head);
        pair=new TextView(this); pair.setTextColor(Color.rgb(180,205,220)); pair.setTextSize(12); box.addView(pair);
        signal=new TextView(this); signal.setText("লোড হচ্ছে…"); signal.setTextColor(Color.WHITE); signal.setTextSize(22); signal.setTypeface(null,1); signal.setPadding(0,dp(5),0,dp(3)); box.addView(signal);
        detail=new TextView(this); detail.setTextColor(Color.LTGRAY); detail.setTextSize(11); box.addView(detail);
        LinearLayout buttons=new LinearLayout(this);
        Button next=new Button(this); next.setText("PAIR"); next.setTextSize(10); buttons.addView(next,new LinearLayout.LayoutParams(0,dp(38),1));
        Button close=new Button(this); close.setText("×"); close.setTextSize(12); buttons.addView(close,new LinearLayout.LayoutParams(0,dp(38),1)); box.addView(buttons);
        next.setOnClickListener(v->{idx=(idx+1)%symbols.length; symbol=symbols[idx]; update();});
        close.setOnClickListener(v->stopSelf());
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(dp(190),WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.TOP|Gravity.RIGHT; lp.x=dp(12);lp.y=dp(110);panel=box;wm.addView(panel,lp);
        panel.setOnTouchListener(new View.OnTouchListener(){float x,y;int ox,oy; boolean moving;
            public boolean onTouch(View v,MotionEvent e){
                if(e.getAction()==MotionEvent.ACTION_DOWN){x=e.getRawX();y=e.getRawY();WindowManager.LayoutParams p=(WindowManager.LayoutParams)panel.getLayoutParams();ox=p.x;oy=p.y;moving=false;return true;}
                if(e.getAction()==MotionEvent.ACTION_MOVE){if(Math.abs(e.getRawX()-x)>dp(4)||Math.abs(e.getRawY()-y)>dp(4))moving=true; if(moving){WindowManager.LayoutParams p=(WindowManager.LayoutParams)panel.getLayoutParams();p.x=ox+(int)(x-e.getRawX());p.y=oy+(int)(e.getRawY()-y);wm.updateViewLayout(panel,p);}return true;}
                return e.getAction()==MotionEvent.ACTION_UP;
            }});
    }
    void update(){
        if(busy)return;busy=true; final String s=symbol;
        net.execute(()->{
            String out="WAIT", why="ডেটা বিশ্লেষণ হচ্ছে"; int score=0; double rsi=50;
            try{
                URL u=new URL("https://api.binance.com/api/v3/klines?symbol="+s+"&interval=1m&limit=80");
                HttpURLConnection c=(HttpURLConnection)u.openConnection();c.setConnectTimeout(7000);c.setReadTimeout(7000);c.setRequestProperty("User-Agent","IQFloatingSignal/1.0");
                InputStream is=c.getInputStream(); ByteArrayOutputStream bos=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=is.read(buf))!=-1)bos.write(buf,0,n);c.disconnect();
                JSONArray a=new JSONArray(new String(bos.toByteArray(),"UTF-8")); ArrayList<Double> closes=new ArrayList<>();
                for(int i=0;i<a.length()-1;i++)closes.add(Double.parseDouble(a.getJSONArray(i).getString(4)));
                if(closes.size()>=30){
                    double ema9=ema(closes,9),ema21=ema(closes,21);rsi=rsi(closes,14);
                    double last=closes.get(closes.size()-1),prev=closes.get(closes.size()-2);
                    if(ema9>ema21)score++;else score--;if(last>prev)score++;else if(last<prev)score--;
                    if(rsi>55)score++;else if(rsi<45)score--;
                    if(score>=2 && rsi<72) {out="UP ▲";why="মোমেন্টাম/EMA অনুকূলে";}
                    else if(score<=-2 && rsi>28){out="DOWN ▼";why="মোমেন্টাম/EMA নিম্নমুখী";}
                    else {out="WAIT";why="সিগন্যাল পরিষ্কার নয়";}
                }
            }catch(Exception ex){out="NO DATA";why="ইন্টারনেট/API ব্যর্থ";}
            final String f=out, w=why;final double rr=rsi; final int sc=score;
            handler.post(()->{if(signal!=null){pair.setText(s+" · 1m");signal.setText(f);signal.setTextColor(f.startsWith("UP")?Color.rgb(0,225,145):f.startsWith("DOWN")?Color.rgb(255,90,100):Color.WHITE);detail.setText(w+"\nRSI "+String.format(Locale.US,"%.1f",rr)+" · Score "+sc+"\nBinance data · auto 15s");}busy=false;});
        });
    }
    double ema(ArrayList<Double> v,int p){double k=2.0/(p+1),e=v.get(0);for(double x:v)e=x*k+e*(1-k);return e;}
    double rsi(ArrayList<Double> v,int p){double g=0,l=0;for(int i=v.size()-p;i<v.size();i++){double d=v.get(i)-v.get(i-1);if(d>0)g+=d;else l-=d;}if(l==0)return 100;return 100-100/(1+g/l);}
    @Override public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
    @Override public void onDestroy(){handler.removeCallbacks(tick);if(net!=null)net.shutdownNow();if(panel!=null&&wm!=null)try{wm.removeView(panel);}catch(Exception ignored){}panel=null;super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
