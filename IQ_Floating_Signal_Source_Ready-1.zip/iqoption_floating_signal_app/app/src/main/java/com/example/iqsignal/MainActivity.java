package com.example.iqsignal;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    TextView status;
    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density); }
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(22),dp(28),dp(22),dp(20)); root.setBackgroundColor(Color.rgb(16,24,32));
        TextView title=new TextView(this); title.setText("IQ Floating Signal"); title.setTextColor(Color.WHITE); title.setTextSize(26); title.setTypeface(null,1); root.addView(title);
        TextView desc=new TextView(this); desc.setText("১-মিনিট চার্ট সহায়ক সিগন্যাল\nসরাসরি IQ Option-এর দাম পড়ে না; Binance BTC/USDT ডেটা দিয়ে বিশ্লেষণ করে।"); desc.setTextColor(Color.LTGRAY); desc.setTextSize(15); desc.setPadding(0,dp(12),0,dp(20)); root.addView(desc);
        Button permission=new Button(this); permission.setText("১. Floating permission চালু করো"); root.addView(permission);
        permission.setOnClickListener(v->{ if(!Settings.canDrawOverlays(this)){ Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())); startActivity(i);} else status.setText("Permission চালু আছে। নিচে Start চাপো।");});
        Button start=new Button(this); start.setText("২. Floating signal চালু করো"); root.addView(start);
        start.setOnClickListener(v->{ if(!Settings.canDrawOverlays(this)){ status.setText("আগে Floating permission চালু করো।"); return;} Intent serviceIntent = new Intent(this,FloatingService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent); else startService(serviceIntent);
            status.setText("Floating signal চালু করার অনুরোধ পাঠানো হয়েছে।");});
        Button stop=new Button(this); stop.setText("Floating signal বন্ধ করো"); root.addView(stop);
        stop.setOnClickListener(v->{ stopService(new Intent(this,FloatingService.class)); status.setText("বন্ধ করা হয়েছে।");});
        status=new TextView(this); status.setTextColor(Color.rgb(0,220,160)); status.setTextSize(14); status.setPadding(0,dp(18),0,0); status.setText("প্রথমে permission দিন, তারপর Start চাপুন।"); root.addView(status);
        TextView foot=new TextView(this); foot.setTextColor(Color.GRAY); foot.setTextSize(12); foot.setPadding(0,dp(24),0,0); foot.setText("সিগন্যাল সম্ভাবনাভিত্তিক, নিশ্চিত নয়। বাস্তব অর্থের আগে ডেমোতে যাচাই করুন।"); root.addView(foot);
        setContentView(root);
    }
}
