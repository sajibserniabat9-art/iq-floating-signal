IQ Floating Signal — Android সোর্স প্রজেক্ট

কী করে
- ভাসমান (floating) প্যানেলে UP / DOWN / WAIT দেখায়।
- BTCUSDT, ETHUSDT, BNBUSDT, SOLUSDT-এর Binance 1-minute candle ব্যবহার করে।
- EMA, RSI এবং সাম্প্রতিক price movement থেকে সহজ নিয়মে সিগন্যাল তৈরি করে; প্রতি ১৫ সেকেন্ডে আপডেটের চেষ্টা করে।

গুরুত্বপূর্ণ সীমাবদ্ধতা
- এটি IQ Option অ্যাপের চার্ট/দাম পড়ে না এবং IQ Option-এর OTC, forex বা অন্য সম্পদের জন্য ডেটা নয়।
- সিগন্যাল নিশ্চিত নয়; লাভ বা win rate-এর কোনো নিশ্চয়তা নেই। আগে demo-তে পরীক্ষা করুন।
- নেটওয়ার্ক/API বন্ধ থাকলে NO DATA দেখাতে পারে।

APK তৈরি (GitHub Actions)
1. এই ZIP extract করে সব ফাইল GitHub repository-এর root-এ আপলোড করুন; ফোল্ডার iqoption_floating_signal_app-এর ভেতরের ফাইলগুলো root-এ থাকতে হবে।
2. repository-তে Actions ট্যাব খুলুন এবং “Build Android APK” workflow নির্বাচন করুন।
3. “Run workflow” চাপুন। প্রথম push-এও workflow স্বয়ংক্রিয়ভাবে চলবে।
4. সফল হলে workflow run খুলে Artifacts অংশ থেকে “IQ-Floating-Signal-APK” ZIP নামান। ZIP extract করে app-debug.apk ফোনে ইনস্টল করুন।
5. Android সেটিংসে “Install unknown apps” অনুমতি দিতে হতে পারে; অ্যাপ খুলে “Floating permission” চালু করে Start চাপুন।

Build setup: Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17, compile SDK 35, minimum Android 6.0 (API 23)।
